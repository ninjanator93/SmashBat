**SmashBat created by Ninjanator93**
- Replaces heavy baseball bat hits with the Bat sound from Super Smash Bros

## Releases

## Version 1.0.0